#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include <unistd.h>
#include <sys/types.h>

main(){

printf("Eryk Janocha %d\n", getpid());
}
